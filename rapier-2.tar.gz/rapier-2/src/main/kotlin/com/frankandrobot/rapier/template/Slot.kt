package com.frankandrobot.rapier.template


class Slot(val name: String, val value: String)
