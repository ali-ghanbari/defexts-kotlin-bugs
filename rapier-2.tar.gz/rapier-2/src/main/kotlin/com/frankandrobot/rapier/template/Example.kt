package com.frankandrobot.rapier.template

import com.frankandrobot.rapier.document.Document


class Example(val template: Template, val document: Document)