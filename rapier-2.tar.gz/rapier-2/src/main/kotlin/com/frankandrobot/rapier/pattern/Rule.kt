package com.frankandrobot.rapier.pattern


class Rule(val preFiller: Pattern, val filler: Pattern, val postFiller: Pattern)
