package com.frankandrobot.rapier.template


class Template(val slots: List<Slot>)
