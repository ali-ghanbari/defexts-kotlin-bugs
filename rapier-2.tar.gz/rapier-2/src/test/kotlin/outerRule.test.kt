/**
 * Created by scottmmjackson on 7/8/16.
 */

package com.frankandrobot.rapier.test

import org.jetbrains.spek.api.Spek

import com.frankandrobot.rapier.outer

class OuterRuleTest : Spek({
  describe("#outer") {
    it("Has no input or output.") {

    }
  }
})
