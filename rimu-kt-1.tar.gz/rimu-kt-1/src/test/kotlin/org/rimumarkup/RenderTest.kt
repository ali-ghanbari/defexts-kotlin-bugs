package org.rimumarkup

/*
TODO

- Tests the Rimu render() API (c.f. rimu-tests.js).

- Test data sourced from CSV or JSON fixture file which is shared between rimu-js and rimu-kotlin
  to ensure both implementations conform to each other.

- First need to rename:
  . Rationalize rimu-tests.js (there's no need for a separate test_span() function).
  . Create shared render-test-data.json fixture.

 */