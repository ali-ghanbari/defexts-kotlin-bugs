package com.danneu.kog

typealias Handler = (Request) -> Response

