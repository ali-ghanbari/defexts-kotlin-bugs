package com.danneu.kog

typealias Middleware = (Handler) -> Handler
