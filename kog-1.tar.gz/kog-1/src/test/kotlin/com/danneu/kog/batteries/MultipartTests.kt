package com.danneu.kog.batteries


import org.junit.Assert.*
import org.junit.Test


class MultipartTests {
    @Test
    fun stub() {
        assertTrue("TODO: Implement me", true)
    }
}


