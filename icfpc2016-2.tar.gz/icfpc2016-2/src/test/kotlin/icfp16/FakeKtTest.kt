package icfp16

import org.junit.Test
import kotlin.test.assertEquals

class FakeKtTest {

  @Test
  fun test() {
    assertEquals("ok", "ok")
  }

  @Test
  fun dummyTest() {
    assertEquals(4, 2+2)
  }

}
