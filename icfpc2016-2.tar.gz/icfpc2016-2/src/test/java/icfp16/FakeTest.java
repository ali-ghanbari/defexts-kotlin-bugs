package icfp16;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class FakeTest {

  @Test
  public void test() {
    assertThat("ok").isEqualTo("ok");
  }

}
