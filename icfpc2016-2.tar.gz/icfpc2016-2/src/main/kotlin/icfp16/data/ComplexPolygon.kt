package icfp16.data

data class ComlexPolygon(val initial: Polygon, val final: Polygon) { }



