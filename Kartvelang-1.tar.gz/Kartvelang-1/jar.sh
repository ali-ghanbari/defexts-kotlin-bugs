#!/bin/bash
./gradlew clean build
exit 0
