package edu.utdallas

/*Created on 29/04/18. */
class Mark(val correct: Boolean, val errorIndices: Set<Int>, val correctAnswer: String) {
}