#!/bin/bash
java -jar build/libs/kartvelang-1.0-SNAPSHOT.jar $1
exit 0
