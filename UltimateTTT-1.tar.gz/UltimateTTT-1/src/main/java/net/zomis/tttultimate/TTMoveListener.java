package net.zomis.tttultimate;

public interface TTMoveListener {
	void onMove(TTBase playedAt);
}
