package net.zomis.tttultimate;

public interface Winnable {

	TTPlayer getWonBy();

}
