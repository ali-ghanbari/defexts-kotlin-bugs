package net.zomis.tttultimate;

public interface TicFactory {
	TTBase construct(TTBase parent, int x, int y);
}
