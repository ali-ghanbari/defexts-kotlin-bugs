Thrifty Gradle Plugin
---------------------

Eventually, this will compile Thrift IDL as part of a standard Gradle build process.
For now, however, it is incomplete and non-functional.