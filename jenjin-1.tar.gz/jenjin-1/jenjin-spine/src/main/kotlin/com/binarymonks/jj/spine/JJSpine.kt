package com.binarymonks.jj.spine

import com.badlogic.gdx.graphics.g2d.PolygonSpriteBatch
import com.esotericsoftware.spine.SkeletonRenderer


object JJSpine {
    val skeletonRenderer = SkeletonRenderer<PolygonSpriteBatch>()
}