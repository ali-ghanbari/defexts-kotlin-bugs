package com.binarymonks.jj.core.physics


data class CollisionGroup(
        val name: String,
        val collisionData: CollisionData
)