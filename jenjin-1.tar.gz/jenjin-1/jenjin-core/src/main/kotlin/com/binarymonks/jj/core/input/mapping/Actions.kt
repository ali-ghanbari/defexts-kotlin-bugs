package com.binarymonks.jj.core.input.mapping

/**
 * Created by lwillmore on 10/02/17.
 */
object Actions {

    enum class Key {
        RELEASED, PRESSED
    }

}
