package com.binarymonks.jj.core.input.mapping

typealias KeyHandler = (keyAction: Actions.Key) -> Boolean

typealias GeneralHandler = () -> Boolean

