package com.binarymonks.jj.core.assets

import kotlin.reflect.KClass

class AssetReference(var clazz: KClass<*>, var assetPath: String)
