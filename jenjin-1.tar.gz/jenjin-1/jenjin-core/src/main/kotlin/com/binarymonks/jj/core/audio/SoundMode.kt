package com.binarymonks.jj.core.audio

/**
 * Created by lwillmore on 04/02/17.
 */
enum class SoundMode {
    NORMAL,
    LOOP
}
