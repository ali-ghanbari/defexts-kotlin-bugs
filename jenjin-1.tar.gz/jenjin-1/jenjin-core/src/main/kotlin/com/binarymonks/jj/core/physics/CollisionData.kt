package com.binarymonks.jj.core.physics

data class CollisionData(val category: Short, val mask: Short)