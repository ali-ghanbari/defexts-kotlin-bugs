package com.binarymonks.jj.core.audio

class Audio {
    var music = MusicController()
    var effects = EffectsController()
}
