package com.binarymonks.jj.core.pools

interface Poolable {

    fun reset()
}
