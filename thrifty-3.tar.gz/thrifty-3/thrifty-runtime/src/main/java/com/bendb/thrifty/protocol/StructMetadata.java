package com.bendb.thrifty.protocol;

public final class StructMetadata {
    public final String name;

    public StructMetadata(String name) {
        this.name = name;
    }
}
