package com.bendb.thrifty.schema;

import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class ThriftTypeTest {
    @Test
    public void tryit() {
        assertEquals(1, 1);
    }
}