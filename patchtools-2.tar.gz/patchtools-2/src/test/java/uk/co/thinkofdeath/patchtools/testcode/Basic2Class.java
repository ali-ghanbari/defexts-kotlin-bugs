package uk.co.thinkofdeath.patchtools.testcode;

public class Basic2Class {
}
