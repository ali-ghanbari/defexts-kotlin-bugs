package uk.co.thinkofdeath.patchtools.patch;

public enum Mode {
    MATCH,
    REMOVE,
    ADD
}
