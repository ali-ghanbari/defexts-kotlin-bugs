package uk.co.thinkofdeath.patchtools.wrappers;

import java.io.File;

public class ClassPathWrapper {

    public ClassPathWrapper(File... libs) {

    }
}
