package ru.ifmo.ctddev.isaev

/**
 * @author iisaev
 */
fun main(args: Array<String>) {
    0.rangeTo(10)
            .forEach { println(it) }
}