package ru.ifmo.ctddev.isaev

fun main(args: Array<String>) {
    val b = arrayOf(doubleArrayOf(1.0, 2.0, 3.0))
}