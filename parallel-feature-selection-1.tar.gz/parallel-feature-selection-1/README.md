# parallel-feature-selection
This is my masters degree project in ITMO University (started as bachelor degree project)

It is an improvement of feature selection algorithm [MeLiF](https://github.com/isae/distributed-feature-selection/raw/master/papers/melif.pdf), invented at our department, 
which generates linear combination of different feature measures to improve feature selection.

My work is to implement this in parallel/distributed manner to accelerate an algorithm.
