package org.luxons.sevenwonders.repositories;

public class PlayerRepositoryTest {

}