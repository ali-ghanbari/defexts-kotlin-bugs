package org.luxons.sevenwonders.errors;

public class ApiMisuseException extends RuntimeException {

    public ApiMisuseException(String message) {
        super(message);
    }
}
