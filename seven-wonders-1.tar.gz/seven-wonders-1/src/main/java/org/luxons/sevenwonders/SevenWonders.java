package org.luxons.sevenwonders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SevenWonders {

    public static void main(String[] args) {
        SpringApplication.run(SevenWonders.class, args);
    }
}
