package org.luxons.sevenwonders.game.scoring;

public enum ScoreCategory {
    CIVIL, SCIENCE, MILITARY, TRADE, GUILD, WONDER, GOLD
}
