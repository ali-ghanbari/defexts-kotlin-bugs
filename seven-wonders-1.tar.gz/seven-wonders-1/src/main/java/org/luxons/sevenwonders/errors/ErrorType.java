package org.luxons.sevenwonders.errors;

public enum ErrorType {
    USER,
    VALIDATION,
    INTERNAL
}
