package org.luxons.sevenwonders.game.boards;

public enum ScienceType {
    COMPASS, WHEEL, TABLET
}
