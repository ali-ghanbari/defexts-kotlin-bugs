package org.luxons.sevenwonders.game.cards;

public enum Color {
    BROWN, GREY, YELLOW, BLUE, GREEN, RED, PURPLE
}
