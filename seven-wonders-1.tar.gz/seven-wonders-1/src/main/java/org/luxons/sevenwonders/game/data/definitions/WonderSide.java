package org.luxons.sevenwonders.game.data.definitions;

public enum WonderSide {
    A, B
}
