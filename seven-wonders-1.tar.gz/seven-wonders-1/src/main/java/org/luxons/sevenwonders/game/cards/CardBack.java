package org.luxons.sevenwonders.game.cards;

public class CardBack {

    private final String image;

    public CardBack(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }
}
