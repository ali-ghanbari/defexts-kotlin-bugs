package org.luxons.sevenwonders.game;

public enum State {
    LOBBY,
    PLAYING
}
