import { INITIALIZE_WS } from "./constants"

export const initializeWs = () => ({
  type: INITIALIZE_WS
})
