export const INITIALIZE_WS = 'app/INITIALIZE_WS'
