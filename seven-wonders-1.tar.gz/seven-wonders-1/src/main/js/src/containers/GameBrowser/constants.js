export const NEW_GAME = 'gameBrowser/NEW_GAME'
export const JOIN_GAME = 'gameBrowser/JOIN_GAME'
export const CREATE_GAME = 'gameBrowser/CREATE_GAME'
