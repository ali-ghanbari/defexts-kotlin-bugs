# Seven Wonders Online

[![Travis Build](https://img.shields.io/travis/luxons/seven-wonders/master.svg)](https://travis-ci.org/joffrey-bion/fx-log)
[![GitHub license](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/luxons/seven-wonders/blob/master/LICENSE)

An digital version of the famous 7 Wonders board game.

We do not own the rights on the Seven Wonder game concept and rules, nor on the assets used here.
